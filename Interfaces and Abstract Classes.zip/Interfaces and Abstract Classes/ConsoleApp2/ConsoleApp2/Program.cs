﻿namespace ConsoleApp2
{
    public abstract class Animal
    {
        public string Name { get; set; }
        public string Colour { get; set; }
        public int Age { get; set; }
        public abstract void Eat();
    }


    public class Dog : Animal
    {

        public override void Eat()
        {
            Console.WriteLine("Dogs eat meat.");
        }
    }

    public class Cat : Animal
    {

        public override void Eat()
        {
            Console.WriteLine("Cats eat mice.");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a dog name: ");
            string dogName = Console.ReadLine();

            Dog dog = new Dog();
            dog.Name = dogName;
            dog.Colour = "black";
            dog.Age = 2;

            Console.WriteLine("Dog properties:");
            Console.WriteLine("Name: " + dog.Name);
            Console.WriteLine("Colour: " + dog.Colour);
            Console.WriteLine("Age: " + dog.Age);
            dog.Eat();

            Cat cat = new Cat();
            cat.Name = "Whiskers";
            cat.Colour = "gray";
            cat.Age = 5;

            Console.WriteLine("Cat properties:");
            Console.WriteLine("Name: " + cat.Name);
            Console.WriteLine("Colour: " + cat.Colour);
            Console.WriteLine("Age: " + cat.Age);
            cat.Eat();

            Console.ReadLine();
        }
    }
}

