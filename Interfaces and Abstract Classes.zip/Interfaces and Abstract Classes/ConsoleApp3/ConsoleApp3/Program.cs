﻿namespace ConsoleApp3
{
    interface IAnimal
    {
        string Name { get; set; }
        string Colour { get; set; }
        int Height { get; set; }
        int Age { get; set; }
        void Eat();
        string Cry();
    }

    class Dog : IAnimal
    {
        public string Name { get; set; }
        public string Colour { get; set; }
        public int Height { get; set; }
        public int Age { get; set; }
        public void Eat()
        {
            Console.WriteLine("Dogs eat meat.");
        }
        public string Cry()
        {
            return "Woof!";
        }
    }

    class Cat : IAnimal
    {
        public string Name { get; set; }
        public string Colour { get; set; }
        public int Height { get; set; }
        public int Age { get; set; }
        public void Eat()
        {
            Console.WriteLine("Cats eat mice.");
        }
        public string Cry()
        {
            return "Meow!";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a dog name: ");
            string dogName = Console.ReadLine();
            Dog myDog = new Dog();
            myDog.Name = dogName;
            Console.Write("Enter dog colour: ");
            myDog.Colour = Console.ReadLine();
            Console.Write("Enter dog height: ");
            myDog.Height = int.Parse(Console.ReadLine());
            Console.Write("Enter dog age: ");
            myDog.Age = int.Parse(Console.ReadLine());
            Console.WriteLine("My dog's name is {0}, {1} in colour, {2} cm tall, and {3} years old.",
                myDog.Name, myDog.Colour, myDog.Height, myDog.Age);
            myDog.Eat();
            Console.WriteLine(myDog.Cry());

            Console.Write("Enter a cat name: ");
            string catName = Console.ReadLine();
            Cat myCat = new Cat();
            myCat.Name = catName;
            Console.Write("Enter cat colour: ");
            myCat.Colour = Console.ReadLine();
            Console.Write("Enter cat height: ");
            myCat.Height = int.Parse(Console.ReadLine());
            Console.Write("Enter cat age: ");
            myCat.Age = int.Parse(Console.ReadLine());
            Console.WriteLine("My cat's name is {0}, {1} in colour, {2} cm tall, and {3} years old.",
                myCat.Name, myCat.Colour, myCat.Height, myCat.Age);
            myCat.Eat();
            Console.WriteLine(myCat.Cry());

            List<IAnimal> animals = new List<IAnimal>();
            animals.Add(myDog);
            animals.Add(myCat);
            animals.Add(new Dog { Name = "Fido", Colour = "Brown", Height = 45, Age = 5 });
            animals.Add(new Cat { Name = "Whiskers", Colour = "Black", Height = 25, Age = 3 });

            Console.WriteLine("List of animals:");
            foreach (IAnimal animal in animals)
            {
                Console.WriteLine(animal.Name);
            }
        }
    }
}