﻿using System;
using System.Collections.Generic;
using System.IO;
namespace inheritance
{
    // Employee class
    class Employee
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string SIN { get; set; }
        public Employee(string id, string name, string sin)
        {
            ID = id;
            Name = name;
            SIN = sin;
        }
        public virtual double CalculateWeeklyPay()
        {
            return 0;
        }
    }
    // SalariedEmployee class
    class SalariedEmployee : Employee
    {
        public double Salary { get; set; }
        public SalariedEmployee(string id, string name, string sin, double salary)
            : base(id, name, sin)
        {
            Salary = salary;
        }
        public override double CalculateWeeklyPay()
        {
            return Salary;
        }
    }
    // WageEmployee class
    class WageEmployee : Employee
    {
        public double HourlyRate { get; set; }
        public double HoursWorked { get; set; }
        public WageEmployee(string id, string name, string sin, double hourlyRate, double hoursWorked)
            : base(id, name, sin)
        {
            HourlyRate = hourlyRate;
            HoursWorked = hoursWorked;
        }
        public override double CalculateWeeklyPay()
        {
            double pay = 0;
            if (HoursWorked <= 40)
            {
                pay = HoursWorked * HourlyRate;
            }
            else
            {
                pay = 40 * HourlyRate + (HoursWorked - 40) * HourlyRate * 1.5;
            }
            return pay;
        }
    }

    // PartTimeEmployee class
    class PartTimeEmployee : Employee
    {
        public double HourlyRate { get; set; }
        public double HoursWorked { get; set; }
        public PartTimeEmployee(string id, string name, string sin, double hourlyRate)
            : base(id, name, sin)
        {
            HourlyRate = hourlyRate;
            HoursWorked = 0;
        }
        public void SetHoursWorked(double hoursWorked)
        {
            HoursWorked = hoursWorked;
        }
        public override double CalculateWeeklyPay()
        {
            return HoursWorked * HourlyRate;
        }
    }
    class Program
    {
        static void Main(string[]args)
        {
            List<Employee> employeeList = new List<Employee>();
            // Read in the employees.txt file
            using (StreamReader reader = new StreamReader("res/employees.txt"))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] splitLine = line.Split(',');
                    // Create new employee objects and add them to the list
                    if (splitLine[0].StartsWith("0") || splitLine[0].StartsWith("1")
                        || splitLine[0].StartsWith("2") || splitLine[0].StartsWith("3")
                        || splitLine[0].StartsWith("4"))
                    {
                        SalariedEmployee salaried = new SalariedEmployee(splitLine[0], splitLine[1], splitLine[2], double.Parse(splitLine[3]));
                        employeeList.Add(salaried);
                    }
                    else if (splitLine[0].StartsWith("5") || splitLine[0].StartsWith("6")
                        || splitLine[0].StartsWith("7"))
                    {
                        WageEmployee wage = new WageEmployee(splitLine[0], splitLine[1], splitLine[2], double.Parse(splitLine[3]), double.Parse(splitLine[4]));
                        employeeList.Add(wage);
                    }
                    else if (splitLine[0].StartsWith("8") || splitLine[0].StartsWith("9"))
                    {
                        PartTimeEmployee partTime = new PartTimeEmployee(splitLine[0], splitLine[1], splitLine[2], double.Parse(splitLine[3]));
                        employeeList.Add(partTime);
                    }
                }
            }

            // Calculate and return the average weekly pay for all employees
            double avgWeeklyPay = 0;
            foreach (Employee employee in employeeList)
            {
                avgWeeklyPay += employee.CalculateWeeklyPay();
            }
            avgWeeklyPay /= employeeList.Count;
            Console.WriteLine("The average weekly pay of all employees is: {0}", avgWeeklyPay);
            // Calculate and return the highest weekly pay for the wage employees, including the name of the employee
            double highestPay = 0;
            string highestName = "";
            foreach (Employee employee in employeeList)
            {
                if (employee is WageEmployee)
                {
                    WageEmployee wageEmployee = (WageEmployee)employee;
                    if (wageEmployee.CalculateWeeklyPay() > highestPay)
                    {
                        highestPay = wageEmployee.CalculateWeeklyPay();
                        highestName = employee.Name;
                    }
                }
            }
            Console.WriteLine("The highest weekly pay of wage employees is: {0} and the name of the employee is {1}", highestPay, highestName);
            // Calculate and return the lowest salary for the salaried employees, including the name of the employee
            double lowestSalary = double.MaxValue;
            string lowestName = "";
            foreach (Employee employee in employeeList)
            {
                if (employee is SalariedEmployee)
                {
                    SalariedEmployee salariedEmployee = (SalariedEmployee)employee;
                    if (salariedEmployee.Salary < lowestSalary)
                    {
                        lowestSalary = salariedEmployee.Salary;
                        lowestName = employee.Name;
                    }
                }
            }

            Console.WriteLine("The lowest salary of salaried employees is: {0} and the name of the employee is {1}", lowestSalary, lowestName);
            // Calculate the percentage of the company's employees fall into each employee category
            int salariedCount = 0;
            int wageCount = 0;
            int partTimeCount = 0;
            foreach (Employee employee in employeeList)
            {
                if (employee is SalariedEmployee)
                {
                    salariedCount++;
                }
                else if (employee is WageEmployee)
                {
                    wageCount++;
                }
                else if (employee is PartTimeEmployee)
                {
                    partTimeCount++;
                }
            }
            double salariedPercent = (double)salariedCount / employeeList.Count * 100;
            double wagePercent = (double)wageCount / employeeList.Count * 100;
            double partTimePercent = (double)partTimeCount / employeeList.Count * 100;
            Console.WriteLine("The percentage of the company's employees fall into each employee category are as follow:");
            Console.WriteLine("Salaried Employees: {0}%, Wage Employees: {1}%, Part-Time Employees: {2}%", salariedPercent, wagePercent, partTimePercent);
        }
    }
}